function largest() {
	return Math.max.apply(null, arguments);
}

module.exports = largest;