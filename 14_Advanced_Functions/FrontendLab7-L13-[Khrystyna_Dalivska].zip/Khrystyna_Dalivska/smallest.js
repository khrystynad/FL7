function smallest() {
	return Math.min.apply(null, arguments);
}

module.exports = smallest;